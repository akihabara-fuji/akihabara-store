import { dayKey } from "./config.js";
import { bump } from "./db.js";
// Mesin AI: coba 9Router (lokal di VPS) lebih dulu bila diisi, lalu Gemini sebagai cadangan.
export function createAi({ cfg, db, fetchImpl = globalThis.fetch }) {
  const env = process.env;
  const rUrl = (env.NINEROUTER_URL || "http://127.0.0.1:20128/v1").replace(/\/$/, "");
  const rKey = env.NINEROUTER_KEY || "";
  const rModels = (env.NINEROUTER_MODELS || "").split(",").map(s => s.trim()).filter(Boolean);
  const gKey = cfg.gemini.key || "";
  const gModel = cfg.gemini.model || "gemini-2.5-flash";
  const hasRouter = () => !!(rKey && rModels.length);
  const ready = () => hasRouter() || !!gKey;
  async function viaRouter(model, o) {
    const messages = [];
    if (o.system) messages.push({ role: "system", content: o.system });
    for (const h of o.history) messages.push({ role: h.role === "model" ? "assistant" : "user", content: (h.parts || []).map(p => p.text || "").join("") });
    messages.push({ role: "user", content: o.user });
    const res = await fetchImpl(rUrl + "/chat/completions", { method: "POST", headers: { "content-type": "application/json", authorization: "Bearer " + rKey },
      body: JSON.stringify({ model, messages, temperature: o.temperature, max_tokens: o.maxTokens, ...(o.json ? { response_format: { type: "json_object" } } : {}) }), signal: AbortSignal.timeout(30000) });
    if (!res.ok) return { ok: false, reason: "ditolak_" + res.status };
    const j = await res.json();
    const text = String((j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || "").trim();
    return text ? { ok: true, text } : { ok: false, reason: "kosong" };
  }
  async function viaGemini(o) {
    const body = { systemInstruction: o.system ? { parts: [{ text: o.system }] } : undefined,
      contents: [...o.history, { role: "user", parts: [{ text: o.user }] }],
      generationConfig: { temperature: o.temperature, maxOutputTokens: o.maxTokens, ...(o.json ? { responseMimeType: "application/json" } : {}) } };
    const res = await fetchImpl(`${cfg.gemini.base}/models/${gModel}:generateContent`, { method: "POST", headers: { "content-type": "application/json", "x-goog-api-key": gKey }, body: JSON.stringify(body), signal: AbortSignal.timeout(20000) });
    if (res.status === 429 || res.status >= 500) return { ok: false, reason: "sibuk" };
    if (!res.ok) return { ok: false, reason: "ditolak_" + res.status };
    const j = await res.json();
    const text = ((j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts) || []).map(p => p.text || "").join("").trim();
    return text ? { ok: true, text } : { ok: false, reason: "kosong" };
  }
  async function ask({ system, user, history = [], who = "anon", temperature = 0.6, maxTokens = 700, json = false, free = false }) {
    if (!ready()) return { ok: false, reason: "belum_diatur" };
    if (!free) {
      const used = db.prepare("SELECT n FROM usage WHERE day=? AND who=?").get(dayKey(), who);
      if (used && used.n >= cfg.limits.aiPerUserPerDay) return { ok: false, reason: "batas_harian" };
    }
    const o = { system, user, history, temperature, maxTokens, json };
    const jobs = [];
    if (hasRouter()) for (const m of rModels) jobs.push(() => viaRouter(m, o));
    if (gKey) jobs.push(() => viaGemini(o));
    let last = { ok: false, reason: "sibuk" };
    for (const job of jobs) {
      try { const r = await job(); if (r.ok) { if (!free) bump(db, "usage", dayKey(), who); return r; } last = r; } catch (e) { last = { ok: false, reason: "timeout" }; }
    }
    return last;
  }
  return { ask, ready };
}
export const AI_DOWN = "Maaf kak, otakku lagi sibuk nih. Coba lagi sebentar ya 🙏";
export const AI_LIMIT = "Jatah tanya AI kakak hari ini sudah habis ya, besok lanjut lagi 🙏";
