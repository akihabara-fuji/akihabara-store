import fs from "node:fs";
const D = "/opt/wabot2/app/src/", H = "/root/pw/";
const files = {};
const get = f => (files[f] ??= fs.readFileSync(D + f, "utf8"));
const snip = n => fs.readFileSync(H + n, "utf8").replace(/\n$/, "");
function rep(f, anchor, text) {
  const s = get(f), c = s.split(anchor).length - 1;
  if (c !== 1) throw new Error(f + ": anchor " + c + "x -> " + anchor.slice(0, 70));
  files[f] = s.replace(anchor, () => text);
}
files["core/ai.js"] = fs.readFileSync(H + "new-ai.js", "utf8");
rep("core/wa.js", "start: connect, sendText,", snip("snip-wa.txt"));
rep("wa1/index.js", "const feat = createFeatures({ db, now }), spam = createAntispam({ db, cfg, now });", snip("snip-top.txt"));
rep("wa1/index.js", "const id = feat.noteAdd(chat, by, it.title, it.text);", snip("snip-note.txt"));
rep("wa1/index.js", "for (const r of feat.remDue()) {", snip("snip-tick.txt"));
rep("wa1/index.js", "const text = stripWake(n.text, cfg.botName), it = parseIntent(text, now());", snip("snip-text.txt"));
rep("wa1/index.js", "|| /^[!/]/.test(n.text);", "|| /^[!/]/.test(n.text) || /^\\s*bot\\b/i.test(n.text);");
for (const [f, c] of Object.entries(files)) fs.writeFileSync(D + f, c);
console.log("PATCH_OK", Object.keys(files).join(","));
